/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl2project;

import java.util.Scanner;

/**
 *
 * @author Mohammed
 */
public class PL2PRoject {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        Login l=new Login();
        l.test();
        // Employee emp = new Employee();
        //Admin a = new Admin();
        //a.admin();
//        Scanner input = new Scanner(System.in);
//        Admin admin = new Admin("Admin@yahoo.com", "12345678", 1, "admin", "admin", 35);
//         int ch = 1;
//
//        String userName, Pass, Fname, Lname, Cname;
//        int id, oldID, age,Cid,oldCID,Pid;
//        System.out.print("\n\nWelecome Admin ... !\n\nUser Name : ");
//        userName = input.next();
//        System.out.print("Password  : ");
//        Pass = input.next();
//        if (admin.login(userName, Pass)) {
//
//            while (ch != 0) {
//                System.out.print("\033[H\033[2J");
//                System.out.flush();
//                System.out.println("\n\t ________________________________\n\t"
//                        + "| Enter 1: Add New TeamLeader.     |\n\t| Enter 2: Add New Employee.   |\n\t| Enter 3: Add New PM.              |\n\t| Enter 4: Add New Task.      |"
//                        + "\n\t| Enter 5: Display All TeamLeader.|\n\t| Enter 6: Display Employees.  |\n\t| Enter 7: Display All PMs.     \n\t| Enter 8: Display Tasks.     |"
//                        + "\n\t| Enter 9: Search TeamLeader.     |\n\t| Enter 10: Search Employees.   |\n\t| Enter 11: Search PM.              |\n\t| Enter 12: Search Task.      |"
//                        + "\n\t| Enter 13: Update TeamLeader.     |\n\t| Enter 14: Update Employees.   |\n\t| Enter 15: Update PM.            |\n\t| Enter 16: Update Task.      |"
//                        + "\n\t| Enter 17: Delete TeamLeader.     |\n\t| Enter 18: Delete Employees.   |\n\t| Enter 19: Delete PM.             |\n\t| Enter 20: Delete Task.      |"
//                        +"\n\t| Enter 21: Add Project.     |\n\t| Enter 22: Display Project.   |\n\t| Enter 23: Search Project.             |\n\t| Enter 24: Update Project.      |"
//                        + "\n\t| Enter 25: Delete Project.     |\n\t|"
//                        + "\n\t -------------------------------\n\t");
//                ch = input.nextInt();
//
//                switch (ch) {
//                    case 1:
//                        System.out.println("Enter TeamLeader Info ... ");
//                        System.out.print("TeamLeader First Name : ");
//                        Fname = input.next();
//                        System.out.print("TeamLeader Last Name : ");
//                        Lname = input.next();
//                        System.out.print("TeamLeader ID : ");
//                        id = input.nextInt();
//                        System.out.print("TeamLeader Age : ");
//                        age = input.nextInt();
//                        System.out.print("Username : ");
//                        userName = input.next();
//                        System.out.print("Password : ");
//                        Pass = input.next();
//                        admin.addNewTeamLeader(userName, Pass, id, Fname, Lname, age);
//                        break;
//                    case 2:
//                        System.out.println("Enter Employee Info ... ");
//                        System.out.print("Employee First Name : ");
//                        Fname = input.next();
//                        System.out.print("Employee Last Name : ");
//                        Lname = input.next();
//                        System.out.print("Employee ID : ");
//                        id = input.nextInt();
//                        System.out.print("Employee Age : ");
//                        age = input.nextInt();
//                        System.out.print("Username : ");
//                        userName = input.next();
//                        System.out.print("Password : ");
//                        Pass = input.next();
//
//                        admin.addNewEmployee(userName, Pass, id, Fname, Lname, age);
//
//                        break;
//                    case 3:
//                        System.out.println("Enter Project Manger Info ... ");
//                        System.out.print("PM First Name : ");
//                        Fname = input.next();
//                        System.out.print("PM Last Name : ");
//                        Lname = input.next();
//                        System.out.print("PM ID : ");
//                        id = input.nextInt();
//                        System.out.print("PM Age : ");
//                        age = input.nextInt();
//                        System.out.print("Username : ");
//                        userName = input.next();
//                        System.out.print("Password : ");
//                        Pass = input.next();
//
//                        admin.addNewPM(userName, Pass, id, Fname, Lname, age);
//
//                        break;
//                   case 4 :
//                        System.out.println("Enter Task Info ... ");
//                        System.out.print("Task Name : ");
//                        Cname = input.next();
//                        System.out.print("Task ID : ");
//                        Cid = input.nextInt();
//                        System.out.print("Project ID : ");
//                        Pid = input.nextInt();
//                        admin.addTask(Cname,Cid,Pid);
//
//                        break;
//                    case 5:
//                        admin.displayTeamLeader();
//                        break;
//
//                    case 6:
//                        admin.displayEmployees();
//                        break;
//
//                    case 7:
//                        admin.displayPMs();
//                        break;
//                    case 8:
//                        admin.displayTasks();
//                        break;
//                    case 9:
//                        System.out.print("\nSearch for TeamLEader ...!\nEnter TeamLeader ID : ");
//                        id = input.nextInt();
//                        admin.searchForTeamLeader(id);
//                        break;
//                    case 10:
//                        System.out.print("\nSearch for Employee ...!\nEnter Employee ID : ");
//                        id = input.nextInt();
//                        admin.searchForEmployee(id);
//                        break;
//                    case 11:
//                        System.out.print("\nSearch for PM ...!\nEnter PM ID : ");
//                        id = input.nextInt();
//                        admin.searchForPMs(id);
//                        break;
//                    case 12:
//                        System.out.print("\nSearch for Task ...!\nEnter Task ID : ");
//                        Cid = input.nextInt();
//                        admin.searchForTask(Cid);
//                        break;
//                    case 13:
//                        System.out.print("\nUpdate TeamLeader info ...!\nEnter TeamLEader OldID : ");
//                        oldID = input.nextInt();
//
//                        System.out.println("\nEnter TeamLeader New Info ... ");
//                        System.out.print("TeamLeader First Name : ");
//                        Fname = input.next();
//                        System.out.print("TeamLeader Last Name : ");
//                        Lname = input.next();
//                        System.out.print("TeamLeader ID : ");
//                        id = input.nextInt();
//                        System.out.print("TeamLeader Age : ");
//                        age = input.nextInt();
//                        System.out.print("Username : ");
//                        userName = input.next();
//                        System.out.print("Password : ");
//                        Pass = input.next();
////                        TeamLeader x = new TeamLeader(userName, Pass, id, Fname, Lname, age);
//
//                        //admin.updateTeamLeader(oldID, x);
//                        break;
//
//                    case 14:
//                        System.out.print("\nUpdate Employee info ...!\nEnter Employee OldID : ");
//                        oldID = input.nextInt();
//                        System.out.println("Enter Employee Info ... ");
//                        System.out.print("Employee First Name : ");
//                        Fname = input.next();
//                        System.out.print("Employee Last Name : ");
//                        Lname = input.next();
//                        System.out.print("Employee ID : ");
//                        id = input.nextInt();
//                        System.out.print("Employee Age : ");
//                        age = input.nextInt();
//                        System.out.print("Username : ");
//                        userName = input.next();
//                        System.out.print("Password : ");
//                        Pass = input.next();
//
//                        Employee y = new Employee(userName, Pass, id, Fname, Lname, age);
//                        admin.updateEmployee(oldID, y);
//                        break;
//                    case 15:
//                        System.out.print("\nUpdate PM info ...!\nEnter PM OldID : ");
//                        oldID = input.nextInt();
//                        System.out.println("Enter Teaching Assistant Info ... ");
//                        System.out.print("PM First Name : ");
//                        Fname = input.next();
//                        System.out.print("PM Last Name : ");
//                        Lname = input.next();
//                        System.out.print("PM ID : ");
//                        id = input.nextInt();
//                        System.out.print("PM Age : ");
//                        age = input.nextInt();
//                        System.out.print("Username : ");
//                        userName = input.next();
//                        System.out.print("Password : ");
//                        Pass = input.next();
//
//                        ProjectManger z = new ProjectManger(userName, Pass, id, Fname, Lname, age);
//                        admin.updatePMs(oldID, z);
//                        break;
//                    case 16:
//                        System.out.print("\nUpdate Task info ...!\nEnter Tsak OldID : ");
//                        oldCID = input.nextInt();
//                        System.out.println("Enter Tasks Info ... ");
//                        System.out.print("Tasks Name : ");
//                        Cname = input.next();
//                        System.out.print("Tasks ID : ");
//                        Cid = input.nextInt();
//                        System.out.print("Project ID : ");
//                        Pid = input.nextInt();
//
//                        Tasks c = new Tasks(Cname, Cid,Pid);
//                        admin.updateTasks(oldCID, c);
//                        break;
//
//                    case 17:
//                        System.out.print("\nDelete TeamLeader info ...!\nEnter TeamLeader ID : ");
//                        id = input.nextInt();
//                        admin.deleteTeamLeader(id);
//                        break;
//
//                    case 18:
//                        System.out.print("\nDelete Employee info ...!\nEnter Employee ID : ");
//                        id = input.nextInt();
//                        admin.deleteEmployee(id);
//                        break;
//
//                    case 19:
//                        System.out.print("\nDelete PM info ...!\nEnter PM ID : ");
//                        id = input.nextInt();
//                        admin.deletePM(id);
//                        break;
//                   case 20:
//                        System.out.print("\nDelete Task info ...!\nEnter Task ID : ");
//                        Cid = input.nextInt();
//                        admin.deleteTask(Cid);
//                        break;
//                   case 21 :
//                        System.out.println("Enter Project Info ... ");
//                        System.out.print("Project Name : ");
//                        Cname = input.next();
//                        System.out.print("Project ID : ");
//                        Cid = input.nextInt();
//                        admin.addProject(Cname,Cid);    
//                        break;
//                   case 22 : 
//                        admin.displayProjects();
//                        break;
//                   case 23 :      
//                        System.out.print("\nSearch for Project ...!\nEnter Project ID : ");
//                        Cid = input.nextInt();
//                        admin.searchForProject(Cid);
//                        break;
//                   case 24 :     
//                       System.out.print("\nUpdate Project info ...!\nEnter Project OldID : ");
//                        oldCID = input.nextInt();
//                        System.out.println("Enter Project Info ... ");
//                        System.out.print("Project Name : ");
//                        Cname = input.next();
//                        System.out.print("Project ID : ");
//                        Cid = input.nextInt();
//
//                        Projects p = new Projects(Cname,Cid);
//                        admin.updateProjects(oldCID, p);
//                        break;
//                   case 25 :
//                        System.out.print("\nDelete Project info ...!\nEnter Project ID : ");
//                        Cid = input.nextInt();
//                        admin.deleteProject(Cid);
//                        break;  
//                    default:
//                        System.out.println("Enter vaild Option :(");
//
//                }
//            }
//        }
       // Employee emp = new Employee();
//    TeamLeaderGUI tm = new TeamLeaderGUI();
    }
    }
    
