/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pl2project;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Mohammed
 */
public class Admin extends Person{
    int id;
   FileManger FManger = new FileManger();
    public Admin() {

    }
    
    public Admin(String user, String pass, int id, String fname, String lname, int age) {
        super( user,  pass,  id,  fname,  lname,  age);
    }

    public void addNewEmployee(String user, String pass, int id, String fname, String lname, int age) {
        Employee x = new Employee(user, pass, id, fname, lname, age);
        if (x.addEmployee()) {
            System.out.println(x.toString() + "Added Successfully ... !");
        } else {
            System.out.println("Failed to insert ... !");
        }
    }

   public void displayEmployees() {
         Employee x = new Employee();
         System.out.println(x.displayAllEmployees());
    }

    public void searchForEmployee(int id) {
        Employee x = new Employee();
        System.out.println(x.searchEmployee(id));
    }

    public void updateEmployee(int oldID, Employee newStudentValues) {
        Employee x = new Employee();
        x.updateEmployee(oldID, newStudentValues);
        System.out.println("Updated Successfully ... !");
    }

    public void deleteEmployee(int Id) {
        Employee x = new Employee();
        x.deleteEmployee(Id);
        System.out.println("deleted Successfully ... !");
    }

    public void addNewTeamLeader(String user, String pass, int id, String fname, String lname, int age) {
        TeamLeader x = new TeamLeader(user, pass, id, fname, lname, age);
        if (x.addTeamLeader()) {
            System.out.println(x.toString() + "Added Successfully ... !");
        } else {
            System.out.println("Failed to insert ... !");
        }
    }

    public void displayTeamLeader() {
         TeamLeader x = new TeamLeader();
         System.out.println(x.displayAllTeamLeader());
    }

    public void searchForTeamLeader(int id) {
        TeamLeader x = new TeamLeader();
        System.out.println(x.searchTeamLeader(id));
    }

    public void updateTeamLeader(int oldID, TeamLeader newProfValues) {
        TeamLeader x = new TeamLeader();
        x.updateTeamLeader(oldID, newProfValues);
        System.out.println("Updated Successfully ... !");
    }

    public void deleteTeamLeader(int Id) {
        TeamLeader x = new TeamLeader();
        x.deleteTeamLeader(Id);
        System.out.println("deleted Successfully ... !");
    }

    public void addNewPM(String user, String pass, int id, String fname, String lname, int age) {
        ProjectManger x = new ProjectManger(user, pass, id, fname, lname, age);
        if (x.addPM()) {
            System.out.println(x.toString() + "Added Successfully ... !");
        } else {
            System.out.println("Failed to insert ... !");
        }
    }

    public void displayPMs() {
        ProjectManger x = new ProjectManger();
        System.out.println(x.displayAllPMs());
    }

    public void searchForPMs(int id) {
        ProjectManger x = new ProjectManger();
        System.out.println(x.searchPM(id));
    }

    public void updatePMs(int oldID, ProjectManger newTAValues) {
        ProjectManger x = new ProjectManger();
        x.updatePM(oldID, newTAValues);
        System.out.println("Updated Successfully ... !");
    }

    public void deletePM(int Id) {
        ProjectManger x = new ProjectManger();
        x.deletePM(Id);
        System.out.println("deleted Successfully ... !");
    }
    public void displayTasks() {
        Tasks x = new Tasks();
        System.out.println(x.displayAllTasks());
    }
//     public void addTask(int id,String TaskName,int TaskId,int ProjectId) {
//        Tasks x = new Tasks(TaskName,TaskId,ProjectId);
//        if (x.addTask()) {
//            System.out.println(x.toString() + "Added Successfully ... !");
//        } else {
//            System.out.println("Failed to insert ... !");
//        }
//    }
     public void searchForTask(int id) {
        Tasks x = new Tasks();
        System.out.println(x.searchTasks(id));
    }
    public void updateTasks(int oldID, Tasks newTaskValues) {
        Tasks x = new Tasks();
        x.updateTasks(oldID, newTaskValues);
        System.out.println("Updated Successfully ... !");
    }
    public void deleteTask(int Id) {
        Tasks x = new Tasks();
        x.deleteTasks(Id);
        System.out.println("deleted Successfully ... !");
    }
   public void displayProjects() {
        Projects x = new Projects();
        System.out.println(x.displayAllProjects());
    }
     public void addProject(String ProjectName,int ProjectId) {
        Projects x = new Projects(ProjectName,ProjectId);
        if (x.addProject()) {
            System.out.println(x.toString() + "Added Successfully ... !");
        } else {
            System.out.println("Failed to insert ... !");
        }
    }
     public void searchForProject(int id) {
        Projects x = new Projects();
        System.out.println(x.searchProjects(id));
    }
    public void updateProjects(int oldID, Projects newProjectValues) {
        Projects x = new Projects();
        x.updateProjects(oldID, newProjectValues);
        System.out.println("Updated Successfully ... !");
    }
    public void deleteProject(int Id) {
        Projects x = new Projects();
        x.deleteProjects(Id);
        System.out.println("deleted Successfully ... !");
    }

    @Override
    public String toString() {
        return "I'm Manager : " + fname + " " + lname + "\n" + "ID : " + id + " Age : " + age  + userName + "\t Password: " + pass + "\n";
    }
    
        public void removeLine(BufferedReader br , File f,  String Line) throws IOException{
    File temp = new File("Employee.txt");
    BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
    String removeID = Line;
    String currentLine;
    while((currentLine = br.readLine()) != "\n"){
        String trimmedLine = currentLine.trim();
        if(trimmedLine.equals(removeID)){
            currentLine = "null";
        }
        bw.write(currentLine + System.getProperty("line.separator"));

    }
    temp.renameTo(f);
    bw.close();
    br.close();
}
    
    public void test(){
         // frame 
    JFrame ft; 
    // Table 
    JTable j; 
    // Frame initiallization 
        ft = new JFrame("display task"); 
        ft.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  
        // Frame Title 
        ft.setTitle("JTable Example"); 
  
        // Data to be displayed in the JTable 
//        String[][1] data =  
//  
//        // Column Names 
//        String[] columnNames = { "project Name", "project id" }; 
//  
//        // Initializing the JTable 
//        j = new JTable(data, columnNames); 
//        j.setBounds(30, 40, 200, 300); 
//  
//        // adding it to JScrollPane 
//        JScrollPane sp = new JScrollPane(j); 
//        ft.add(sp); 
//        // Frame Size 
        ft.setSize(500, 200); 

    
    
    
    
    
    
    
    
    
    
    
    
        //frames
        JFrame f1 = new JFrame("admin ");
        f1.setSize(710, 600);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setVisible(true);

        
        JFrame em = new JFrame("emplyee");
        em.setSize(700, 600);
        em.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        em.setVisible(false);        em.setLayout(null);

        
        
        JFrame p = new JFrame("Project manager");
        p.setSize(710,600);
        p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        p.setLayout(null);
        
        
        JFrame t = new JFrame(" team");
        t.setSize(710, 600);
        t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        t.setLayout(null);
        
        
            //admain frame
           
            JMenuBar mb = new JMenuBar();
           JMenu m1 = new JMenu("edit");
           JButton m2 = new JButton("view tasks");
           JMenuItem m11 = new JMenuItem("employee");
           JMenuItem m22 = new JMenuItem("team leader");
           JMenuItem m33 = new JMenuItem("project managment");
            JPanel panel = new JPanel(); 
            Font newFont = new Font("Serif", Font.BOLD, 25);
            JLabel label = new JLabel("Welcome to Admin ");
            f1.getContentPane().add(BorderLayout.CENTER, panel);
            f1.getContentPane().add(BorderLayout.NORTH, mb);

            label.setFont(newFont);
            panel.add(label); 
            mb.add(m1);
            mb.add(m2);
            m1.add(m11);
            m1.add(m33);
            m1.add(m22);
        
        
            
            //label em
            JLabel l1 = new JLabel("users");
            JLabel l2 = new JLabel("ID");
            JLabel l3 = new JLabel("First Name");
            JLabel l4 = new JLabel("Last Name ");
            JLabel l5 = new JLabel("age");
            JLabel l6 = new JLabel("password");
            l1.setBounds(30, 50, 100, 25);
            l2.setBounds(30, 90, 100, 25);
            l3.setBounds(30, 130, 100, 25);
            l4.setBounds(30, 170, 100, 25);
            l5.setBounds(30, 210, 100, 25);
            l6.setBounds(30, 250, 100, 25);
            
            //textfileand password
            JTextField jTextFieldUserName = new JTextField();
            JTextField jTextFieldID = new JTextField();
            JTextField jTextFieldFname = new JTextField();
            JTextField jTextFieldLname = new JTextField();
            JTextField jTextFieldAge = new JTextField();
            JPasswordField jPasswordField1 = new JPasswordField(); 
            jTextFieldUserName.setBounds(120, 50, 130, 25);
            jTextFieldID.setBounds(120, 90, 130, 25);
            jTextFieldFname.setBounds(120, 130, 130, 25);
            jTextFieldLname.setBounds(120, 170, 130, 25);
            jTextFieldAge.setBounds(120, 210, 130, 25);
            jPasswordField1.setBounds(120, 250, 130, 25);
            //button
            JButton btn_add = new JButton("Add");
            JButton btn_clear = new JButton("delete");
            JButton btn_update = new JButton("update");
            btn_add.setBounds(150, 300, 70, 30);
            btn_clear.setBounds(70, 300, 70, 30);
            btn_update.setBounds(230,300 ,90 ,30 );
            //add em
            em.add(l1);
            em.add(l2);
            em.add(l3);
            em.add(l4);
            em.add(l5);
            em.add(l6);
            em.add(jTextFieldUserName);
            em.add(jTextFieldID);
            em.add(jTextFieldFname);
            em.add(jTextFieldLname);
            em.add(jTextFieldAge);
            em.add(jPasswordField1);
            em.add(btn_add);
            em.add(btn_clear);
            em.add(btn_update);

            //add t
                        JLabel lt = new JLabel("users");
            JLabel lt2 = new JLabel("ID");
            JLabel lt3 = new JLabel("First Name");
            JLabel lt4 = new JLabel("Last Name ");
            JLabel lt5 = new JLabel("age");
            JLabel lt6 = new JLabel("password");
            lt.setBounds(30, 50, 100, 25);
            lt2.setBounds(30, 90, 100, 25);
            lt3.setBounds(30, 130, 100, 25);
            lt4.setBounds(30, 170, 100, 25);
            lt5.setBounds(30, 210, 100, 25);
            lt6.setBounds(30, 250, 100, 25);
            
            //textfileand password
            JTextField tUser = new JTextField();
            JTextField tID = new JTextField();
            JTextField tFname = new JTextField();
            JTextField tLname = new JTextField();
            JTextField tAge = new JTextField();
            JPasswordField tPassword1 = new JPasswordField(); 
            tUser.setBounds(120, 50, 130, 25);
            tID.setBounds(120, 90, 130, 25);
            tFname.setBounds(120, 130, 130, 25);
            tLname.setBounds(120, 170, 130, 25);
            tAge.setBounds(120, 210, 130, 25);
            tPassword1.setBounds(120, 250, 130, 25);
            //button
            JButton tadd = new JButton("Add");
            JButton tclear = new JButton("delete");
            JButton tupdate = new JButton("update");
            tadd.setBounds(150, 300, 70, 30);
            tclear.setBounds(70, 300, 70, 30);
            tupdate.setBounds(230,300 ,90 ,30 );
            t.add(lt);
            t.add(lt2);
            t.add(lt3);
            t.add(lt4);
            t.add(lt5);
            t.add(lt6);
            t.add(tUser);
            t.add(tID);
            t.add(tFname);
            t.add(tLname);
            t.add(tAge);
            t.add(tPassword1);
            t.add(tadd);
            t.add(tclear);
            t.add(tupdate);
            
            //add p
            JLabel lp1 = new JLabel("users");
            JLabel lp2 = new JLabel("ID");
            JLabel lp3 = new JLabel("First Name");
            JLabel lp4 = new JLabel("Last Name ");
            JLabel lp5 = new JLabel("age");
            JLabel lp6 = new JLabel("password");
            lp1.setBounds(30, 50, 100, 25);
            lp2.setBounds(30, 90, 100, 25);
            lp3.setBounds(30, 130, 100, 25);
            lp4.setBounds(30, 170, 100, 25);
            lp5.setBounds(30, 210, 100, 25);
            lp6.setBounds(30, 250, 100, 25);
            
            //textfileand password
            JTextField pUser = new JTextField();
            JTextField pID = new JTextField();
            JTextField pFname = new JTextField();
            JTextField pLname = new JTextField();
            JTextField pAge = new JTextField();
            JPasswordField pPassword1 = new JPasswordField(); 
            pUser.setBounds(120, 50, 130, 25);
            pID.setBounds(120, 90, 130, 25);
            pFname.setBounds(120, 130, 130, 25);
            pLname.setBounds(120, 170, 130, 25);
            pAge.setBounds(120, 210, 130, 25);
            pPassword1.setBounds(120, 250, 130, 25);
            //button
            JButton padd = new JButton("Add");
            JButton pclear = new JButton("delete");
            JButton pupdate = new JButton("update");
            padd.setBounds(150, 300, 70, 30);
            pclear.setBounds(70, 300, 70, 30);
            pupdate.setBounds(230,300 ,90 ,30 );
            p.add(lp1);
            p.add(lp2);
            p.add(lp3);
            p.add(lp4);
            p.add(lp5);
            p.add(lp6);
            p.add(pUser);
            p.add(pID);
            p.add(pFname);
            p.add(pLname);
            p.add(pAge);
            p.add(pPassword1);
            p.add(padd);
            p.add(pclear);
            p.add(pupdate);


            //Actions;     
           m11.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    f1.setVisible(false);
                    em.setVisible(true);
                   

                }
          });
            m2.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    f1.setVisible(false);
                    ft.setVisible(true);
                   

                }
          });
           
           
         btn_add.addActionListener(new ActionListener(){
         @Override
         public void actionPerformed(ActionEvent e) {
           
           if (!jTextFieldID.getText().equals("") && !jTextFieldFname.getText().equals("") && !jTextFieldLname.getText().equals("") && !jTextFieldUserName.getText().equals("") && !jPasswordField1.getText().equals("") && !jTextFieldAge.getText().equals("")) {

            Admin x = new Admin();
            x.setID(Integer.parseInt(jTextFieldID.getText()));
            x.setFName(jTextFieldFname.getText());
            x.setLName(jTextFieldLname.getText());
            x.setUserName(jTextFieldUserName.getText());
            x.setPass(jPasswordField1.getText());
            x.setAge(Integer.parseInt(jTextFieldAge.getText()));
            

            x.setAge(Integer.parseInt(jTextFieldAge.getText()));
            
            
            x.addNewEmployee(x.userName, x.pass,x.id , x.fname,x.lname , x.age);
                   
                   
           }

//                  try (BufferedWriter fileOut = new BufferedWriter(new FileWriter("Employee.txt",true))) {
//                  jTextFieldID.write(fileOut);
//                  fileOut.append("@");
//                  jTextFieldFname.write(fileOut);
//                  fileOut.append("@");
//                  jTextFieldLname.write(fileOut);
//                  fileOut.append("@");
//                  jTextFieldUserName.write(fileOut);
//                 fileOut.append("@");
//                  jPasswordField1.write(fileOut);
//                  
//                  fileOut.append("~");
//                  fileOut.newLine();
//                  fileOut.close();
//                  f1.dispose();
//                  em.setVisible(false);
//                  f1.setVisible(true);
//                 
                  
//                  }     
                    
//                catch (IOException ex) {
//                 Logger.getLogger(ProjectManger.class.getName()).log(Level.SEVERE, null, ex);
//             }
       }});
         
    


           
               m33.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    f1.setVisible(false);
                    p.setVisible(true);

                }
          });
               m22.addActionListener(new ActionListener(){
                @Override
                public void actionPerformed(ActionEvent e) {
                    f1.setVisible(false);
                    t.setVisible(true);

                }
          });
               
               
    btn_clear.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent evt) {

            Admin xd = new Admin ();
            xd.setID(Integer.parseInt(jTextFieldID.getText()));
            xd.deleteEmployee(xd.id);

//        BufferedReader br = null;
//    try{
//    String id = jTextFieldID .getText();
//        File books = new File("Employee.txt");
//         br = new BufferedReader(new FileReader(books));
//         removeLine(br , books,id );
//        // System.out.println("done");
//
//    }catch (NumberFormatException e1) {
//              // System.out.println("This is not a number");
//    } catch (IOException e) {
        // TODO Auto-generated catch block
       // e.printStackTrace();
//    }



//    }
    }});
               
 
    
    }
    @Override
    public boolean login(String userName, String Pass) {

        if (userName.equals("a") && Pass.equals("1")) {
            return true;
        }
        return false;

    }
}
